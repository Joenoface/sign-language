import os
from flask import Flask, request, jsonify, render_template
import joblib
import json
import numpy as np
import tensorflow as tf
import cv2
import mediapipe as mp

app = Flask(__name__)

# Load model artifacts once
dir_path = os.path.dirname(os.path.realpath(__file__))
model = tf.keras.models.load_model(os.path.join(dir_path, 'model', 'sign_language_model.keras'))
scaler = joblib.load(os.path.join(dir_path, 'model', 'scaler.save'))
with open(os.path.join(dir_path, 'model', 'labels.json'), 'r') as f:
    labels = json.load(f)

# Setup MediaPipe
mp_hands = mp.solutions.hands
hands = mp_hands.Hands(static_image_mode=False,
                       max_num_hands=1,
                       min_detection_confidence=0.5)
mp_draw = mp.solutions.drawing_utils

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    # Expect JPEG image bytes
    file = request.files.get('frame')
    if file is None:
        return jsonify({'error': 'No frame provided'}), 400

    # Read image from bytes
    arr = np.frombuffer(file.read(), np.uint8)
    img = cv2.imdecode(arr, cv2.IMREAD_COLOR)
    img_rgb = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)

    res = hands.process(img_rgb)
    if not res.multi_hand_landmarks:
        return jsonify({'sign': None})

    # Extract first hand landmarks
    lm = res.multi_hand_landmarks[0].landmark
    feats = []
    for p in lm:
        feats.extend([p.x, p.y, p.z])
    vec = np.array([feats])

    # Normalize & scale
    wrist = vec[0, :3]
    vec = vec - np.repeat(wrist, vec.shape[1]//3)
    vec = scaler.transform(vec)

    # Predict
    pred = model.predict(vec, verbose=0)
    idx = int(np.argmax(pred))
    sign = labels[str(idx)]

    return jsonify({'sign': sign})

if __name__ == '__main__':
    app.run(debug=True)