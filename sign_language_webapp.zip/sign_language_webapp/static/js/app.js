const video = document.getElementById('video');
const canvas = document.getElementById('canvas');
const ctx = canvas.getContext('2d');
const predictionDiv = document.getElementById('prediction');

// Set canvas size same as video
canvas.width = 480;
canvas.height = 360;

// Start webcam
navigator.mediaDevices.getUserMedia({ video: true })
  .then(stream => { video.srcObject = stream; })
  .catch(err => { console.error('Webcam error:', err); });

// Capture & send every 500ms
setInterval(() => {
  if (video.readyState !== HTMLMediaElement.HAVE_ENOUGH_DATA) return;
  ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
  canvas.toBlob(blob => {
    const form = new FormData();
    form.append('frame', blob, 'frame.jpg');
    fetch('/predict', { method: 'POST', body: form })
      .then(res => res.json())
      .then(data => {
        predictionDiv.textContent = data.sign || 'No hand detected';
      })
      .catch(err => console.error(err));
  }, 'image/jpeg');
}, 500);