# Sign Language Detection Web App

A minimal Flask-based web application for real-time American Sign Language (ASL) detection using MediaPipe and a trained TensorFlow model. The app captures live webcam video, sends frames to the backend for inference, and displays the predicted sign on a clean, blue-gradient UI.

---

## 📂 Project Structure

```
sign_language_webapp/
├── app.py                  # Flask application
├── requirements.txt        # Python dependencies
├── model/                  # Trained model artifacts
│   ├── sign_language_model.keras
│   ├── scaler.save
│   └── labels.json
├── templates/              # HTML templates
│   └── index.html
├── static/                 # Static assets
│   ├── css/
│   │   └── style.css       # Blue-gradient styling
│   └── js/
│       └── app.js          # Webcam capture & prediction logic
└── logs/                   # (Optional) TensorBoard logs
```

---

## 🚀 Getting Started

Follow these steps to run the app locally.

### 1. Clone this repository

```bash
git clone <your-repo-url>
cd sign_language_webapp
```

### 2. Create a virtual environment (recommended)

```bash
python3 -m venv .venv
# On Windows (PowerShell): .\.venv\Scripts\Activate.ps1
# On Windows (cmd.exe):   .\.venv\Scripts\activate.bat
source .venv/bin/activate  # macOS/Linux
```

### 3. Install dependencies

```bash
pip install --upgrade pip
pip install -r requirements.txt
```

### 4. Add your trained model

Ensure the following files are present under the `model/` directory:

* `sign_language_model.keras`
* `scaler.save`
* `labels.json`

If you used the provided training pipeline (`train_model.py`), these will be generated automatically.

### 5. Run the application

```bash
python app.py
```

Navigate to `http://localhost:5000` in your browser to see the app in action.

---

## 🛠️ Project Details

### Backend (`app.py`)

* **Flask** server exposing two routes:

  * `/`: Renders the main HTML page.
  * `/predict`: Accepts a JPEG frame, processes it with MediaPipe, normalizes landmarks, and returns the predicted ASL sign.

* **MediaPipe Hands** for hand landmark extraction.

* **TensorFlow** for loading and running the trained model.

* **Scikit-learn** `StandardScaler` for feature normalization.

### Frontend (`index.html` + `app.js`)

* **Webcam Capture:** Uses `getUserMedia` to access the camera.
* **Canvas:** Grabs frames at 480×360 resolution.
* **Fetch API:** Sends frames to `/predict` every 500ms.
* **UI:** Displays the current prediction or a "No hand detected" message.

### Styling (`style.css`)

* Minimal design with a **blue gradient** background.
* Responsive container centered vertically and horizontally.

---

## ⚙️ Customization & Extensions

* **Dockerize** the app for containerized deployment.
* **Add authentication** if you plan to expose the API publicly.
* **Optimize latency** by batching frames or lowering resolution.
* **Support multiple hands** by adapting the inference logic.
* **Switch frameworks** (e.g., FastAPI or Node.js) for performance comparisons.

---

## 🙏 Credits

* Built with [Flask](https://flask.palletsprojects.com/)
* Hand-tracking via [MediaPipe](https://mediapipe.dev/)
* Model training with [TensorFlow/Keras](https://www.tensorflow.org/) and [scikit-learn](https://scikit-learn.org/)

---


